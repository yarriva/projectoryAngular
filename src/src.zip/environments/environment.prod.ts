export const environment = {
  production: true,
  firebase:{
    apiKey: "AIzaSyCQMi3_lo6oklA0bR5JADu4K8n2AYDG6U0",
    authDomain: "projectory-e0463.firebaseapp.com",
    databaseURL: "https://projectory-e0463.firebaseio.com",
    projectId: "projectory-e0463",
    storageBucket: "projectory-e0463.appspot.com",
    messagingSenderId: "255892263719",
    appId: "1:255892263719:web:59b7dbc45855622d11cf02",
    measurementId: "G-SD0NYP22QE"
  }
};
